#ifndef UTILITIES_H
#define UTILITIES_H

void printArr(int*, int);

int intInput(char*, int, int);
 
#endif
