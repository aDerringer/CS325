#ifndef FILEIO_H
#define FILEIO_H

void outputArr(char*, int*, int);
 
void arrFile(char*, int);

#endif
