#ifndef SORT_H
#define SORT_H

//#include <stdio.h>
//#include <stdlib.h>

void insertSort(int*, int);
void merge(int*, int, int, int);
void mergeSort(int*, int, int);

#endif
